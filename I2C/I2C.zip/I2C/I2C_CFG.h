/*
 * I2C_CFG.h
 *
 * Created: 11/3/2023 2:33:22 PM
 *  Author: Ali
 */ 


#ifndef I2C_CFG_H_
#define I2C_CFG_H_





#endif /* I2C_CFG_H_ */