#include "StdTypes.h"
#include "Sensors_Interface.h"
void ATHM_Int(void)
{
	
}

void ATHM_Runnable(void)
{
	
}
/* C*/
Error_t LED_GetTemp(u8 ledTdx,s16*PTemp);


u16 ATHM_GetDeratingRatio(void)
{
	
}