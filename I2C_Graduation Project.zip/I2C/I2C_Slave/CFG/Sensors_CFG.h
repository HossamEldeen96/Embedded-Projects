

#ifndef SENSORS_CFG_H_
#define SENSORS_CFG_H_


#define LM35_CH CH_0
#define MPX4115_CH CH_7



#endif /* SENSORS_CFG_H_ */