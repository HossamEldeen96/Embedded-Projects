
#include "Keypad_CFG.h"

#ifndef KEYPAD_INTERFACE_H_
#define KEYPAD_INTERFACE_H_


void KEYPAD_Init(void);
u8 Keypad_GetKey(void);


#endif /* KEYPAD_INTERFACE_H_ */