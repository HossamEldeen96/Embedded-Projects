/*
 * GIE_Private.h
 *
 * Created: 10/22/2023 1:51:30 PM
 *  Author: Ali
 */ 


#ifndef GIE_PRIVATE_H_
#define GIE_PRIVATE_H_

#include "std_types.h"

#define SREG *((volatile uint8 *)0x5F)
#define I_BIT 7



#endif /* GIE_PRIVATE_H_ */