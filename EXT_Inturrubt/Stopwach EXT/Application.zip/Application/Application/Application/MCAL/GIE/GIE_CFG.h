/*
 * GIE_CFG.h
 *
 * Created: 10/22/2023 1:52:12 PM
 *  Author: Ali
 */ 


#ifndef GIE_CFG_H_
#define GIE_CFG_H_




#endif /* GIE_CFG_H_ */