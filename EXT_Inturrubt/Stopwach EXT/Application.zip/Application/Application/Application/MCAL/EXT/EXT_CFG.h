
#ifndef EXT_CFG_H_
#define EXT_CFG_H_

typedef enum{EXT0, EXT1, EXT2}INTS;
typedef enum{LOW_Level, CHANGE, FALLING, RISING}SENS;


#endif /* EXT_CFG_H_ */